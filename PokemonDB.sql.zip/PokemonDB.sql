-- phpMyAdmin SQL Dump
-- version 4.2.6deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 14, 2015 at 06:27 PM
-- Server version: 5.5.40-0ubuntu1
-- PHP Version: 5.5.12-2ubuntu4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `PokemonDB`
--

-- --------------------------------------------------------

--
-- Table structure for table `BADGE`
--

CREATE TABLE IF NOT EXISTS `BADGE` (
  `badge_id` int(8) NOT NULL,
  `badge_name` varchar(30) NOT NULL,
  `badge_obedience_level` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `BADGE`
--

INSERT INTO `BADGE` (`badge_id`, `badge_name`, `badge_obedience_level`) VALUES
(1, 'Boulder Badge', NULL),
(2, 'Cascade Badge', 30),
(3, 'Thunder Badge', NULL),
(4, 'Rainbow Badge', 50),
(5, 'Soul Badge', NULL),
(6, 'Marsh Badge', 70),
(7, 'Volcano Badge', NULL),
(8, 'Earth Badge', 100);

-- --------------------------------------------------------

--
-- Table structure for table `EARNED_BADGE`
--

CREATE TABLE IF NOT EXISTS `EARNED_BADGE` (
  `badge_id` int(1) NOT NULL,
  `trainer_id` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `EARNED_BADGE`
--

INSERT INTO `EARNED_BADGE` (`badge_id`, `trainer_id`) VALUES
(1, 1),
(1, 2),
(2, 2),
(1, 3),
(2, 3),
(3, 3),
(1, 4),
(2, 4),
(3, 4),
(4, 4),
(1, 5),
(2, 5),
(3, 5),
(4, 5),
(5, 5),
(1, 6),
(2, 6),
(3, 6),
(4, 6),
(5, 6),
(6, 6),
(1, 7),
(2, 7),
(3, 7),
(4, 7),
(5, 7),
(6, 7),
(7, 7),
(1, 8),
(2, 8),
(3, 8),
(4, 8),
(5, 8),
(6, 8),
(7, 8),
(8, 8),
(1, 9),
(2, 9),
(3, 9),
(4, 9),
(5, 9),
(6, 9),
(7, 9),
(1, 10),
(2, 10),
(3, 10),
(4, 10),
(5, 10),
(6, 10),
(7, 10),
(8, 10),
(1, 25),
(3, 25),
(4, 25),
(6, 25),
(7, 25),
(8, 25),
(1, 26),
(2, 26),
(5, 26),
(6, 26),
(7, 26),
(1, 27),
(2, 27),
(3, 27),
(4, 27),
(1, 28),
(2, 28);

-- --------------------------------------------------------

--
-- Table structure for table `GYM`
--

CREATE TABLE IF NOT EXISTS `GYM` (
`gym_id` int(11) NOT NULL,
  `gym_name` varchar(30) NOT NULL,
  `gym_city` varchar(30) NOT NULL,
  `gym_type` int(2) DEFAULT NULL,
  `gym_badge` int(1) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `GYM`
--

INSERT INTO `GYM` (`gym_id`, `gym_name`, `gym_city`, `gym_type`, `gym_badge`) VALUES
(1, 'Pewter Gym', 'Pewter City', 6, 1),
(2, 'Cerulean Gym', 'Cerulean City', 10, 2),
(3, 'Vermilion Gym', 'Vermilion City', 12, 3),
(4, 'Celadon Gym', 'Celadon City', 11, 4),
(5, 'Fuchsia Gym', 'Fuchsia City', 4, 5),
(6, 'Saffron Gym', 'Saffron City', 13, 6),
(7, 'Cinnabar Gym', 'Cinnabar Island', 9, 7),
(8, 'Viridian Gym', 'Viridian City', 5, 8);

-- --------------------------------------------------------

--
-- Table structure for table `GYM_LEADER`
--

CREATE TABLE IF NOT EXISTS `GYM_LEADER` (
  `gym_id` int(11) NOT NULL,
  `trainer_id` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `GYM_LEADER`
--

INSERT INTO `GYM_LEADER` (`gym_id`, `trainer_id`) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 5),
(6, 6),
(7, 7),
(8, 8);

-- --------------------------------------------------------

--
-- Table structure for table `OWNED_POKEMON`
--

CREATE TABLE IF NOT EXISTS `OWNED_POKEMON` (
  `pokemon_id` char(3) NOT NULL,
  `trainer_id` int(3) NOT NULL,
  `pokemon_level` int(3) DEFAULT '5'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `OWNED_POKEMON`
--

INSERT INTO `OWNED_POKEMON` (`pokemon_id`, `trainer_id`, `pokemon_level`) VALUES
('001', 25, 5),
('002', 26, 34),
('002', 27, 5),
('004', 26, 6),
('005', 28, 5),
('006', 9, 42),
('007', 28, 22),
('008', 27, 5),
('009', 10, 52),
('011', 28, 5),
('012', 9, 15),
('012', 28, 22),
('016', 26, 22),
('019', 28, 5),
('025', 3, 18),
('025', 9, 45),
('026', 3, 24),
('028', 27, 45),
('031', 8, 44),
('031', 9, 37),
('031', 10, 41),
('034', 8, 45),
('034', 10, 44),
('037', 27, 18),
('039', 25, 5),
('041', 28, 5),
('045', 4, 29),
('049', 6, 38),
('051', 8, 42),
('058', 7, 42),
('059', 7, 47),
('059', 10, 47),
('064', 6, 38),
('065', 6, 43),
('071', 4, 29),
('074', 1, 12),
('077', 7, 40),
('078', 7, 42),
('085', 10, 38),
('089', 5, 39),
('095', 1, 14),
('098', 10, 15),
('099', 9, 28),
('100', 3, 21),
('109', 5, 37),
('110', 5, 43),
('111', 8, 45),
('112', 8, 50),
('114', 4, 24),
('120', 2, 18),
('121', 2, 21),
('122', 6, 37),
('126', 10, 36);

-- --------------------------------------------------------

--
-- Table structure for table `POKEMON`
--

CREATE TABLE IF NOT EXISTS `POKEMON` (
  `pokemon_id` char(3) NOT NULL,
  `pokemon_name` varchar(25) NOT NULL,
  `pokemon_type1` int(2) NOT NULL,
  `pokemon_type2` int(2) DEFAULT NULL,
  `pokemon_hp` int(3) NOT NULL,
  `pokemon_speed` int(3) NOT NULL,
  `pokemon_attack` int(3) NOT NULL,
  `pokemon_special_attack` int(3) NOT NULL,
  `pokemon_defense` int(3) NOT NULL,
  `pokemon_special_defense` int(3) NOT NULL,
  `pokemon_before` char(3) DEFAULT NULL,
  `pokemon_before_evo_level` int(2) DEFAULT NULL,
  `pokemon_after` char(3) DEFAULT NULL,
  `pokemon_after_evo_level` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `POKEMON`
--

INSERT INTO `POKEMON` (`pokemon_id`, `pokemon_name`, `pokemon_type1`, `pokemon_type2`, `pokemon_hp`, `pokemon_speed`, `pokemon_attack`, `pokemon_special_attack`, `pokemon_defense`, `pokemon_special_defense`, `pokemon_before`, `pokemon_before_evo_level`, `pokemon_after`, `pokemon_after_evo_level`) VALUES
('001', 'Bulbasaur', 11, 4, 45, 45, 49, 65, 49, 65, NULL, NULL, '002', 16),
('002', 'Ivysaur', 11, 4, 60, 60, 62, 80, 63, 80, '001', 16, '003', 32),
('003', 'Venusaur', 11, 4, 80, 80, 82, 100, 83, 100, '002', 32, NULL, NULL),
('004', 'Charmander', 9, NULL, 39, 65, 52, 60, 43, 50, NULL, NULL, '005', 16),
('005', 'Charmeleon', 9, NULL, 58, 80, 64, 80, 58, 65, '004', 16, '006', 32),
('006', 'Charizard', 9, 3, 78, 100, 84, 109, 78, 85, '005', 32, NULL, NULL),
('007', 'Squirtle', 10, NULL, 44, 43, 48, 50, 65, 64, NULL, NULL, '008', 16),
('008', 'Wartortle', 10, NULL, 59, 58, 63, 65, 80, 80, '007', 16, '009', 32),
('009', 'Blastoise', 10, NULL, 79, 78, 83, 85, 100, 105, '008', 16, NULL, NULL),
('010', 'Caterpie', 7, NULL, 45, 45, 30, 20, 35, 20, NULL, NULL, '011', 7),
('011', 'Metapod', 7, NULL, 50, 30, 20, 25, 55, 25, '010', 7, '012', 10),
('012', 'Butterfree', 7, 3, 60, 70, 45, 90, 50, 80, '011', 10, NULL, NULL),
('013', 'Weedle', 7, 4, 40, 50, 35, 20, 30, 20, '014', 7, NULL, NULL),
('014', 'Kakuna', 7, 4, 45, 35, 25, 25, 50, 25, '013', 7, '015', 10),
('015', 'Beedrill', 7, 4, 65, 75, 90, 45, 40, 80, '014', 10, NULL, NULL),
('016', 'Pidgey', 1, 3, 40, 56, 45, 35, 40, 35, NULL, NULL, '017', 18),
('017', 'Pidgeotto', 1, 3, 63, 71, 60, 50, 55, 50, ' 01', 18, '018', 36),
('018', 'Pidgeot', 1, 3, 83, 101, 80, 70, 75, 70, '017', 36, NULL, NULL),
('019', 'Rattata', 1, NULL, 30, 72, 56, 25, 35, 35, NULL, NULL, '020', 20),
('020', 'Raticate', 1, NULL, 55, 97, 81, 50, 60, 70, '019', 20, NULL, NULL),
('021', 'Spearow', 1, 3, 40, 70, 60, 31, 30, 31, NULL, NULL, '022', 20),
('022', 'Fearow', 1, 3, 65, 100, 90, 61, 65, 61, '021', 20, NULL, NULL),
('023', 'Ekans', 4, NULL, 35, 55, 60, 40, 44, 54, NULL, NULL, '024', 22),
('024', 'Arbok', 4, NULL, 60, 80, 85, 65, 69, 79, '023', 22, NULL, NULL),
('025', 'Pikachu', 12, NULL, 35, 90, 55, 50, 40, 50, NULL, NULL, '026', NULL),
('026', 'Raichu', 12, NULL, 60, 110, 90, 90, 55, 80, '025', NULL, NULL, NULL),
('027', 'Sandshrew', 5, NULL, 50, 40, 75, 20, 85, 30, NULL, NULL, '028', 22),
('028', 'Sandslash', 5, NULL, 75, 65, 100, 45, 110, 55, '027', 22, NULL, NULL),
('029', 'Nidoran&#9792;', 4, NULL, 55, 41, 47, 40, 52, 40, NULL, NULL, '030', 16),
('030', 'Nidorina', 4, NULL, 70, 56, 62, 55, 67, 55, '029', 16, '031', NULL),
('031', 'Nidoqueen', 4, 5, 90, 76, 92, 75, 87, 85, '030', NULL, NULL, NULL),
('032', 'Nidoran&#9794;', 4, NULL, 46, 50, 57, 40, 40, 40, NULL, NULL, '033', 16),
('033', 'Nidorino', 4, NULL, 61, 65, 72, 55, 57, 55, '032', 16, '034', NULL),
('034', 'Nidoking', 4, 5, 81, 85, 102, 85, 77, 75, '033', NULL, NULL, NULL),
('035', 'Clefairy', 1, NULL, 70, 35, 45, 60, 48, 65, NULL, NULL, '036', NULL),
('036', 'Clefable', 1, NULL, 95, 60, 70, 95, 73, 90, '035', NULL, NULL, NULL),
('037', 'Vulpix', 9, NULL, 38, 65, 41, 50, 40, 65, NULL, NULL, '038', NULL),
('038', 'Ninetales', 9, NULL, 73, 100, 76, 81, 75, 100, '037', NULL, NULL, NULL),
('039', 'Jigglypuff', 1, NULL, 115, 20, 45, 45, 20, 25, NULL, NULL, '040', NULL),
('040', 'Wigglytuff', 1, NULL, 140, 45, 70, 85, 45, 50, '039', NULL, NULL, NULL),
('041', 'Zubat', 4, 3, 40, 55, 45, 30, 35, 40, NULL, NULL, '042', 22),
('042', 'Golbat', 4, 3, 75, 90, 80, 65, 70, 75, '041', 22, NULL, NULL),
('043', 'Oddish', 11, 4, 45, 30, 50, 75, 55, 65, NULL, NULL, '044', 21),
('044', 'Gloom', 11, 4, 60, 40, 65, 85, 70, 75, '043', 21, '045', NULL),
('045', 'Vileplume', 11, 4, 75, 50, 80, 110, 85, 90, '044', NULL, NULL, NULL),
('046', 'Paras', 7, 11, 35, 25, 70, 45, 55, 55, NULL, NULL, '047', 24),
('047', 'Parasect', 7, 11, 60, 30, 95, 60, 80, 80, '046', 24, NULL, NULL),
('048', 'Venonat', 7, 4, 60, 45, 55, 40, 50, 55, NULL, NULL, '049', 31),
('049', 'Venomoth', 7, 4, 70, 90, 65, 90, 60, 75, '048', 31, NULL, NULL),
('050', 'Diglett', 5, NULL, 10, 95, 55, 25, 35, 45, NULL, NULL, '051', 26),
('051', 'Dugtrio', 5, NULL, 35, 120, 80, 50, 50, 70, '050', 26, NULL, NULL),
('052', 'Meowth', 1, NULL, 40, 90, 45, 35, 40, 40, NULL, NULL, '053', 28),
('053', 'Persian', 1, NULL, 65, 115, 70, 60, 65, 65, '052', 28, NULL, NULL),
('054', 'Psyduck', 10, NULL, 50, 55, 52, 48, 65, 50, NULL, NULL, '055', 33),
('055', 'Golduck', 10, NULL, 80, 85, 82, 78, 95, 80, '054', 33, NULL, NULL),
('056', 'Mankey', 2, NULL, 40, 70, 80, 35, 35, 45, NULL, NULL, '057', 28),
('057', 'Primeape', 2, NULL, 65, 95, 105, 60, 60, 70, '056', 28, NULL, NULL),
('058', 'Growlithe', 9, NULL, 55, 60, 70, 45, 70, 50, '059', NULL, NULL, NULL),
('059', 'Arcanine', 9, NULL, 90, 95, 110, 80, 100, 80, '058', NULL, NULL, NULL),
('060', 'Poliwag', 10, NULL, 40, 90, 50, 40, 40, 40, NULL, NULL, '061', 25),
('061', 'Poliwhirl', 10, NULL, 65, 90, 65, 65, 50, 50, '060', 24, '062', NULL),
('062', 'Poliwrath', 10, 2, 90, 70, 95, 95, 70, 90, '061', NULL, NULL, NULL),
('063', 'Abra', 13, NULL, 25, 90, 20, 15, 105, 55, NULL, NULL, '064', 16),
('064', 'Kadabra', 13, NULL, 40, 105, 35, 30, 120, 70, '063', 16, '065', NULL),
('065', 'Alakazam', 13, NULL, 55, 120, 50, 45, 135, 95, '064', NULL, NULL, NULL),
('066', 'Machop', 2, NULL, 70, 35, 80, 50, 35, 35, NULL, NULL, '067', 28),
('067', 'Machoke', 2, NULL, 80, 45, 100, 70, 50, 60, '066', 28, '068', NULL),
('068', 'Machamp', 2, NULL, 90, 55, 130, 80, 65, 85, '067', NULL, NULL, NULL),
('069', 'Bellsprout', 11, 4, 50, 40, 75, 35, 70, 30, NULL, NULL, '070', 21),
('070', 'Weepinbell', 11, 4, 65, 55, 90, 50, 85, 45, '069', 21, '071', NULL),
('071', 'Victreebel', 11, 4, 80, 70, 105, 65, 100, 70, '070', NULL, NULL, NULL),
('072', 'Tentacool', 10, 4, 40, 70, 40, 35, 50, 100, NULL, NULL, '073', 30),
('073', 'Tentacruel', 10, 4, 80, 100, 70, 65, 80, 120, '072', 30, NULL, NULL),
('074', 'Geodude', 6, 5, 40, 20, 80, 100, 30, 30, NULL, NULL, '075', 25),
('075', 'Graveler', 6, 5, 55, 35, 95, 115, 45, 45, '074', 25, '076', NULL),
('076', 'Golem', 6, 5, 80, 45, 120, 130, 55, 65, '075', NULL, NULL, NULL),
('077', 'Ponyta', 9, NULL, 50, 90, 85, 55, 65, 65, NULL, NULL, '078', 40),
('078', 'Rapidash', 9, NULL, 65, 105, 100, 70, 80, 80, '077', 40, NULL, NULL),
('079', 'Slowpoke', 10, 13, 90, 15, 65, 65, 40, 40, NULL, NULL, '080', 37),
('080', 'Slowbro', 10, 13, 95, 30, 75, 110, 100, 80, '079', 37, NULL, NULL),
('081', 'Magnemite', 12, NULL, 25, 45, 35, 70, 95, 55, NULL, NULL, '082', 30),
('082', 'Magneton', 12, NULL, 50, 70, 60, 95, 120, 70, '081', 30, NULL, NULL),
('083', 'Farfetch''d', 1, 3, 52, 60, 65, 55, 58, 62, NULL, NULL, NULL, NULL),
('084', 'Doduo', 1, 3, 35, 75, 85, 45, 35, 35, NULL, NULL, '085', 31),
('085', 'Dodrio', 1, 3, 60, 100, 110, 70, 60, 60, '084', 31, NULL, NULL),
('086', 'Seel', 10, NULL, 65, 45, 45, 55, 45, 70, NULL, NULL, '087', 34),
('087', 'Dewgong', 10, 14, 90, 70, 70, 80, 70, 95, '086', 34, NULL, NULL),
('088', 'Grimer', 4, NULL, 80, 25, 80, 50, 40, 50, NULL, NULL, '089', 38),
('089', 'Muk', 4, NULL, 105, 50, 105, 75, 65, 100, '088', 38, NULL, NULL),
('090', 'Shellder', 10, NULL, 30, 40, 65, 100, 45, 25, NULL, NULL, '091', NULL),
('091', 'Cloyster', 10, 14, 50, 70, 95, 180, 85, 45, '090', NULL, NULL, NULL),
('092', 'Gastly', 8, 4, 30, 80, 35, 30, 100, 35, NULL, NULL, '093', 25),
('093', 'Haunter', 8, 4, 45, 95, 50, 45, 115, 55, '092', 25, '094', NULL),
('094', 'Gengar', 8, 4, 60, 110, 65, 60, 130, 75, '093', NULL, NULL, NULL),
('095', 'Onix', 6, 5, 35, 70, 45, 160, 30, 45, NULL, NULL, NULL, NULL),
('096', 'Drowzee', 13, NULL, 60, 42, 48, 45, 43, 90, NULL, NULL, '097', 26),
('097', 'Hypno', 13, NULL, 85, 67, 73, 70, 73, 115, '096', 26, NULL, NULL),
('098', 'Krabby', 10, NULL, 30, 50, 105, 90, 25, 25, NULL, NULL, '099', 28),
('099', 'Kingler', 10, NULL, 55, 75, 130, 115, 50, 50, '098', 28, NULL, NULL),
('100', 'Voltorb', 12, NULL, 40, 100, 30, 55, 50, 55, NULL, NULL, '101', 30),
('101', 'Electrode', 12, NULL, 60, 140, 50, 80, 70, 80, '101', 30, NULL, NULL),
('102', 'Exeggcute', 11, 13, 60, 40, 40, 60, 80, 45, NULL, NULL, '103', NULL),
('103', 'Exeggutor', 11, 13, 95, 55, 95, 125, 85, 65, '102', NULL, NULL, NULL),
('104', 'Cubone', 5, NULL, 50, 35, 50, 40, 95, 50, NULL, NULL, '105', 28),
('105', 'Marowak', 5, NULL, 60, 45, 80, 50, 110, 80, '104', 28, NULL, NULL),
('106', 'Hitmonlee', 2, NULL, 50, 87, 120, 35, 53, 110, NULL, NULL, NULL, NULL),
('107', 'Hitmonchan', 2, NULL, 50, 76, 105, 35, 79, 110, NULL, NULL, NULL, NULL),
('108', 'Lickitung', 1, NULL, 90, 30, 55, 60, 75, 75, NULL, NULL, NULL, NULL),
('109', 'Koffing', 4, NULL, 40, 35, 65, 60, 95, 45, NULL, NULL, '110', 35),
('110', 'Weezing', 4, NULL, 65, 60, 90, 85, 120, 70, '109', 35, NULL, NULL),
('111', 'Rhyhorn', 5, 6, 80, 25, 85, 30, 95, 30, NULL, NULL, '112', 42),
('112', 'Rhydon', 5, 6, 105, 40, 130, 45, 120, 45, '111', 42, NULL, NULL),
('113', 'Chansey', 1, NULL, 250, 50, 5, 35, 5, 105, NULL, NULL, NULL, NULL),
('114', 'Tangela', 11, NULL, 65, 60, 55, 100, 115, 40, NULL, NULL, NULL, NULL),
('115', 'Kangaskhan', 1, NULL, 105, 90, 95, 40, 80, 80, NULL, NULL, NULL, NULL),
('116', 'Horsea', 10, NULL, 30, 60, 40, 70, 70, 25, NULL, NULL, '117', 32),
('117', 'Seadra', 10, NULL, 55, 85, 65, 95, 95, 45, '116', 32, NULL, NULL),
('118', 'Goldeen', 10, NULL, 45, 63, 67, 35, 60, 50, NULL, NULL, '119', 33),
('119', 'Seaking', 10, NULL, 80, 68, 92, 65, 65, 80, '118', 33, NULL, NULL),
('120', 'Staryu', 10, NULL, 30, 85, 45, 70, 55, 55, NULL, NULL, '121', NULL),
('121', 'Starmie', 10, 13, 60, 115, 75, 100, 85, 85, '120', NULL, NULL, NULL),
('122', 'Mr. Mime', 13, NULL, 40, 90, 45, 100, 65, 120, NULL, NULL, NULL, NULL),
('123', 'Scyther', 11, 3, 70, 105, 110, 55, 80, 80, NULL, NULL, NULL, NULL),
('124', 'Jynx', 14, 13, 65, 95, 50, 115, 35, 95, NULL, NULL, NULL, NULL),
('125', 'Electabuzz', 12, NULL, 65, 105, 83, 95, 57, 85, NULL, NULL, NULL, NULL),
('126', 'Magmar', 9, NULL, 65, 93, 95, 100, 57, 85, NULL, NULL, NULL, NULL),
('127', 'Pinsir', 7, NULL, 65, 85, 125, 55, 100, 70, NULL, NULL, NULL, NULL),
('128', 'Tauros', 1, NULL, 75, 110, 100, 40, 95, 70, NULL, NULL, NULL, NULL),
('129', 'Magikarp', 10, NULL, 20, 80, 10, 15, 55, 20, NULL, NULL, '130', 20),
('130', 'Gyarados', 10, 3, 95, 81, 125, 60, 79, 100, '129', 20, NULL, NULL),
('131', 'Lapras', 10, 14, 130, 60, 85, 85, 80, 95, NULL, NULL, NULL, NULL),
('132', 'Ditto', 1, NULL, 48, 48, 48, 48, 48, 48, NULL, NULL, NULL, NULL),
('133', 'Eevee', 1, NULL, 55, 55, 55, 45, 50, 65, NULL, NULL, '134', NULL),
('134', 'Vaporeon', 10, NULL, 130, 65, 65, 110, 60, 95, '133', NULL, NULL, NULL),
('135', 'Jolteon', 12, NULL, 65, 130, 65, 110, 60, 95, '133', NULL, NULL, NULL),
('136', 'Flareon', 9, NULL, 65, 65, 130, 95, 60, 110, '133', NULL, NULL, NULL),
('137', 'Porygon', 1, NULL, 65, 40, 60, 85, 70, 75, NULL, NULL, NULL, NULL),
('138', 'Omanyte', 6, 10, 35, 35, 40, 90, 100, 55, NULL, NULL, '139', 40),
('139', 'Omastar', 6, 10, 70, 55, 60, 115, 125, 70, '138', 40, NULL, NULL),
('140', 'Kabuto', 6, 10, 30, 55, 80, 55, 90, 45, NULL, NULL, '141', 40),
('141', 'Kabutops', 6, 10, 60, 80, 115, 65, 105, 70, '140', 40, NULL, NULL),
('142', 'Aerodactyl', 6, 3, 80, 130, 105, 60, 65, 75, NULL, NULL, NULL, NULL),
('143', 'Snorlax', 1, NULL, 160, 20, 110, 65, 65, 110, NULL, NULL, NULL, NULL),
('144', 'Articuno', 14, 3, 90, 85, 85, 95, 100, 125, NULL, NULL, NULL, NULL),
('145', 'Zapdos', 12, 3, 90, 100, 90, 125, 85, 90, NULL, NULL, NULL, NULL),
('146', 'Moltres', 9, 3, 90, 90, 100, 125, 90, 85, NULL, NULL, NULL, NULL),
('147', 'Dratini', 15, NULL, 41, 50, 64, 50, 45, 50, NULL, NULL, '148', 30),
('148', 'Dragonair', 15, NULL, 61, 70, 84, 70, 65, 70, '147', 30, '149', 55),
('149', 'Dragonite', 15, 3, 91, 80, 134, 100, 95, 100, '148', 55, NULL, NULL),
('150', 'Mewtwo', 13, NULL, 106, 130, 110, 154, 90, 90, NULL, NULL, NULL, NULL),
('151', 'Mew', 13, NULL, 100, 100, 100, 100, 100, 100, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `TRAINER`
--

CREATE TABLE IF NOT EXISTS `TRAINER` (
`trainer_id` int(3) NOT NULL,
  `trainer_name` varchar(25) NOT NULL,
  `trainer_rival` int(3) DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=33 ;

--
-- Dumping data for table `TRAINER`
--

INSERT INTO `TRAINER` (`trainer_id`, `trainer_name`, `trainer_rival`) VALUES
(1, 'Brock', NULL),
(2, 'Misty', NULL),
(3, 'Lt. Surge', NULL),
(4, 'Erika', NULL),
(5, 'Koga', NULL),
(6, 'Sabrina', NULL),
(7, 'Blaine', NULL),
(8, 'Giovanni', NULL),
(9, 'Ash', 10),
(10, 'Gary', 9),
(25, 'Alex', 7),
(26, 'Jon', NULL),
(27, 'Jonathan', 1),
(28, 'Barrack', 10);

-- --------------------------------------------------------

--
-- Table structure for table `TYPE`
--

CREATE TABLE IF NOT EXISTS `TYPE` (
  `type_id` int(2) NOT NULL,
  `type_name` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `TYPE`
--

INSERT INTO `TYPE` (`type_id`, `type_name`) VALUES
(1, 'Normal'),
(2, 'Fighting'),
(3, 'Flying'),
(4, 'Poison'),
(5, 'Ground'),
(6, 'Rock'),
(7, 'Bug'),
(8, 'Ghost'),
(9, 'Fire'),
(10, 'Water'),
(11, 'Grass'),
(12, 'Electric'),
(13, 'Psychic'),
(14, 'Ice'),
(15, 'Dragon');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `BADGE`
--
ALTER TABLE `BADGE`
 ADD PRIMARY KEY (`badge_id`);

--
-- Indexes for table `EARNED_BADGE`
--
ALTER TABLE `EARNED_BADGE`
 ADD PRIMARY KEY (`badge_id`,`trainer_id`), ADD KEY `trainer_id` (`trainer_id`);

--
-- Indexes for table `GYM`
--
ALTER TABLE `GYM`
 ADD PRIMARY KEY (`gym_id`), ADD KEY `gym_type` (`gym_type`), ADD KEY `gym_badge` (`gym_badge`);

--
-- Indexes for table `GYM_LEADER`
--
ALTER TABLE `GYM_LEADER`
 ADD PRIMARY KEY (`gym_id`,`trainer_id`), ADD KEY `trainer_id` (`trainer_id`);

--
-- Indexes for table `OWNED_POKEMON`
--
ALTER TABLE `OWNED_POKEMON`
 ADD PRIMARY KEY (`pokemon_id`,`trainer_id`), ADD KEY `trainer_id` (`trainer_id`);

--
-- Indexes for table `POKEMON`
--
ALTER TABLE `POKEMON`
 ADD PRIMARY KEY (`pokemon_id`), ADD KEY `pokemon_type1` (`pokemon_type1`), ADD KEY `pokemon_type2` (`pokemon_type2`);

--
-- Indexes for table `TRAINER`
--
ALTER TABLE `TRAINER`
 ADD PRIMARY KEY (`trainer_id`), ADD KEY `trainer_rival` (`trainer_rival`);

--
-- Indexes for table `TYPE`
--
ALTER TABLE `TYPE`
 ADD PRIMARY KEY (`type_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `GYM`
--
ALTER TABLE `GYM`
MODIFY `gym_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `TRAINER`
--
ALTER TABLE `TRAINER`
MODIFY `trainer_id` int(3) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=33;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `EARNED_BADGE`
--
ALTER TABLE `EARNED_BADGE`
ADD CONSTRAINT `EARNED_BADGE_ibfk_1` FOREIGN KEY (`badge_id`) REFERENCES `BADGE` (`badge_id`),
ADD CONSTRAINT `EARNED_BADGE_ibfk_2` FOREIGN KEY (`trainer_id`) REFERENCES `TRAINER` (`trainer_id`);

--
-- Constraints for table `GYM`
--
ALTER TABLE `GYM`
ADD CONSTRAINT `GYM_ibfk_1` FOREIGN KEY (`gym_type`) REFERENCES `TYPE` (`type_id`),
ADD CONSTRAINT `GYM_ibfk_2` FOREIGN KEY (`gym_badge`) REFERENCES `BADGE` (`badge_id`);

--
-- Constraints for table `GYM_LEADER`
--
ALTER TABLE `GYM_LEADER`
ADD CONSTRAINT `GYM_LEADER_ibfk_1` FOREIGN KEY (`gym_id`) REFERENCES `GYM` (`gym_id`),
ADD CONSTRAINT `GYM_LEADER_ibfk_2` FOREIGN KEY (`trainer_id`) REFERENCES `TRAINER` (`trainer_id`);

--
-- Constraints for table `OWNED_POKEMON`
--
ALTER TABLE `OWNED_POKEMON`
ADD CONSTRAINT `OWNED_POKEMON_ibfk_1` FOREIGN KEY (`pokemon_id`) REFERENCES `POKEMON` (`pokemon_id`),
ADD CONSTRAINT `OWNED_POKEMON_ibfk_2` FOREIGN KEY (`trainer_id`) REFERENCES `TRAINER` (`trainer_id`);

--
-- Constraints for table `POKEMON`
--
ALTER TABLE `POKEMON`
ADD CONSTRAINT `POKEMON_ibfk_1` FOREIGN KEY (`pokemon_type1`) REFERENCES `TYPE` (`type_id`),
ADD CONSTRAINT `POKEMON_ibfk_2` FOREIGN KEY (`pokemon_type2`) REFERENCES `TYPE` (`type_id`);

--
-- Constraints for table `TRAINER`
--
ALTER TABLE `TRAINER`
ADD CONSTRAINT `TRAINER_ibfk_1` FOREIGN KEY (`trainer_rival`) REFERENCES `TRAINER` (`trainer_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
